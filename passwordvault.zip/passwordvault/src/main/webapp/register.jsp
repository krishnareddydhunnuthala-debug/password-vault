<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Password Vault — Register</title>
    <style>
        body{font-family:Arial;background:#eef2ff;display:flex;align-items:center;justify-content:center;height:100vh;}
        .card{background:#fff;padding:24px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.08);width:320px;}
        input{width:100%;padding:8px;margin:8px 0;border-radius:4px;border:1px solid #ccd;}
        button{width:100%;padding:10px;border:none;border-radius:5px;background:green;color:#fff;}
    </style>
</head>
<body>
<div class="card">
    <h2>Create account</h2>
    <form action="register" method="post">
        <input name="user" required placeholder="Username">
        <input name="pass" type="password" required placeholder="Password">
        <button type="submit">Register</button>
    </form>
    <p style="margin-top:12px"><a href="index.jsp">Back to login</a></p>
</div>
</body>
</html>
