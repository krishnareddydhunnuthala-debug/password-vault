<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Password Vault — Login</title>
    <style>
        body{font-family:Arial;background:#eef2ff;display:flex;align-items:center;justify-content:center;height:100vh;}
        .card{background:#fff;padding:24px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.08);width:320px;}
        input{width:100%;padding:8px;margin:8px 0;border-radius:4px;border:1px solid #ccd;}
        button{width:100%;padding:10px;border:none;border-radius:5px;background:#1d72ff;color:#fff;}
        a{font-size:0.9em;}
    </style>
</head>
<body>
<div class="card">
    <h2>Login</h2>
    <form action="login" method="post">
        <input name="user" required placeholder="Username">
        <input name="pass" type="password" required placeholder="Password">
        <button type="submit">Login</button>
    </form>
    <p style="margin-top:12px">No account? <a href="register.jsp">Create one</a></p>
</div>
</body>
</html>
