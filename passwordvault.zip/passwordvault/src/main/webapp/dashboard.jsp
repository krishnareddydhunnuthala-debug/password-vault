<%@ page import="passmanag.com.*, java.util.*" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) { response.sendRedirect("index.jsp"); return; }
    ArrayList<PasswordEntry> list = UserStore.getVault(user);
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><%= user %>'s Vault</title>
    <style>
        body{font-family:Arial;background:#f7f9ff;padding:30px;}
        .top{display:flex;justify-content:space-between;align-items:center;}
        .card{background:#fff;padding:16px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.05);}
        table{width:100%;border-collapse:collapse;margin-top:12px;}
        td,th{padding:8px;border-bottom:1px solid #eee;text-align:left;}
        .mask{font-family:monospace;letter-spacing:2px;}
        button.copy{padding:6px 10px;border-radius:6px;border:none;background:#1d72ff;color:#fff;cursor:pointer;}
        form.add{margin-top:12px;}
        input{padding:6px;border:1px solid #ddd;border-radius:4px;margin-right:8px;}
    </style>
    <script>
        async function copyPass(id) {
            try {
                const res = await fetch('getPass?id=' + id);
                if (!res.ok) { alert('Error: ' + res.status); return; }
                const text = await res.text();
                await navigator.clipboard.writeText(text);
                alert('Password copied to clipboard');
            } catch (e) { alert('Error copying'); }
        }
    </script>
</head>
<body>
<div class="top">
    <h2>Hello, <%= user %></h2>
    <div><a href="logout">Logout</a></div>
</div>

<div class="card">
    <h3>Add new password</h3>
    <form class="add" action="addPass" method="post">
        <input name="site" placeholder="Website (e.g. example.com)" required>
        <input name="pass" placeholder="Password" type="password" required>
        <button type="submit">Add</button>
    </form>

    <h3 style="margin-top:18px">Your saved passwords</h3>
    <table>
        <tr><th>Website</th><th>Password</th><th>Action</th></tr>
        <%
            if (list == null || list.isEmpty()) {
        %>
            <tr><td colspan="3">No passwords saved yet.</td></tr>
        <%
            } else {
                for (PasswordEntry p : list) {
        %>
            <tr>
                <td><%= p.getSite() %></td>
                <td class="mask">************</td>
                <td>
    <button class="copy" type="button" onclick="copyPass(<%= p.getId() %>)">Copy</button>
    <form action="deletePass" method="post" style="display:inline;">
        <input type="hidden" name="id" value="<%= p.getId() %>">
        <button type="submit" style="background:red;color:white;border:none;padding:5px 10px;border-radius:4px;cursor:pointer;">Delete</button>
    </form>
</td>
                
            </tr>
        <%
                }
            }
        %>
    </table>
</div>
</body>
</html>
