package passmanag.com;

import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.ServletException;

@WebServlet("/getPass")
public class GetPassServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("user") == null) {
            resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
            resp.getWriter().println("Forbidden");
            return;
        }
        String user = (String) s.getAttribute("user");
        String idParam = req.getParameter("id");
        if (idParam == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().println("Missing id");
            return;
        }
        int id;
        try { id = Integer.parseInt(idParam); } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().println("Bad id");
            return;
        }

        PasswordEntry entry = UserStore.getEntry(user, id);
        if (entry == null) {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            resp.getWriter().println("Not found");
            return;
        }

        // decrypt and return plaintext password
        String decrypted = CryptoUtil.decryptAES(entry.getEncryptedPassword());
        resp.setContentType("text/plain");
        resp.getWriter().print(decrypted == null ? "" : decrypted);
    }
}
