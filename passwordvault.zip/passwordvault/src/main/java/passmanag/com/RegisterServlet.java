package passmanag.com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("user");
        String pass = req.getParameter("pass");
        if (username == null || pass == null || username.isEmpty() || pass.isEmpty()) {
            resp.getWriter().println("Missing username or password.");
            return;
        }

        boolean ok = UserStore.register(username.trim(), pass);
        if (ok) {
            resp.sendRedirect("index.jsp?msg=registered");
        } else {
            resp.getWriter().println("Username already exists. <a href='register.jsp'>Try again</a>");
        }
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect("register.jsp");
    }
}
