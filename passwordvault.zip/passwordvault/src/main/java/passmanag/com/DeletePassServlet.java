package passmanag.com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/deletePass")
public class DeletePassServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("user") == null) {
            resp.sendRedirect("index.jsp");
            return;
        }

        String user = (String) s.getAttribute("user");
        String idParam = req.getParameter("id");
        if (idParam != null) {
            try {
                int id = Integer.parseInt(idParam);
                UserStore.deletePassword(user, id);
            } catch (NumberFormatException e) { /* ignore invalid id */ }
        }

        resp.sendRedirect("dashboard.jsp");
    }
}
