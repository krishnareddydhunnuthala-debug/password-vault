package passmanag.com;

public class PasswordEntry {
    private final int id;
    private final String site;
    private final String encryptedPassword; // AES encrypted base64

    public PasswordEntry(int id, String site, String encryptedPassword) {
        this.id = id;
        this.site = site;
        this.encryptedPassword = encryptedPassword;
    }

    public int getId() { return id; }
    public String getSite() { return site; }
    public String getEncryptedPassword() { return encryptedPassword; }
}
