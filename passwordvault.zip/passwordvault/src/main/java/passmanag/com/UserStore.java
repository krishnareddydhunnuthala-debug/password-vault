package passmanag.com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class UserStore {
    // username -> sha256(hashed login password)
    private static final HashMap<String, String> users = new HashMap<>();

    // username -> list of PasswordEntry
    private static final HashMap<String, ArrayList<PasswordEntry>> vaults = new HashMap<>();

    // id generator for password entries
    private static final AtomicInteger idGen = new AtomicInteger(1);

    // Register user (return false if exists)
    public static synchronized boolean register(String username, String rawPassword) {
        if (users.containsKey(username)) return false;
        users.put(username, CryptoUtil.sha256(rawPassword));
        vaults.put(username, new ArrayList<>());
        return true;
    }

    // Check login (sha256)
    public static boolean login(String username, String rawPassword) {
        if (!users.containsKey(username)) return false;
        String storedHash = users.get(username);
        String givenHash = CryptoUtil.sha256(rawPassword);
        return storedHash != null && storedHash.equals(givenHash);
    }

    // Add password to user's vault (stored encrypted)
    public static synchronized int addPassword(String username, String site, String rawPassword) {
        if (!vaults.containsKey(username)) return -1;
        String encrypted = CryptoUtil.encryptAES(rawPassword);
        int id = idGen.getAndIncrement();
        PasswordEntry entry = new PasswordEntry(id, site, encrypted);
        vaults.get(username).add(entry);
        return id;
    }

    // Get vault list for username
    public static ArrayList<PasswordEntry> getVault(String username) {
        return vaults.get(username);
    }

    // Get specific entry by id for a user (or null)
    public static PasswordEntry getEntry(String username, int id) {
        ArrayList<PasswordEntry> list = vaults.get(username);
        if (list == null) return null;
        for (PasswordEntry p : list) if (p.getId() == id) return p;
        return null;
    }
    
 // Delete password by ID
    public static synchronized void deletePassword(String username, int id) {
        ArrayList<PasswordEntry> list = vaults.get(username);
        if (list != null) {
            list.removeIf(p -> p.getId() == id);
        }
    }

}
