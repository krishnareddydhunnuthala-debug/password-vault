package passmanag.com;

import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.ServletException;

@WebServlet("/addPass")
public class AddPassServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("user") == null) {
            resp.sendRedirect("index.jsp");
            return;
        }
        String user = (String) s.getAttribute("user");
        String site = req.getParameter("site");
        String pass = req.getParameter("pass");

        if (site == null || pass == null || site.isEmpty() || pass.isEmpty()) {
            resp.getWriter().println("Missing fields. <a href='dashboard.jsp'>Back</a>");
            return;
        }

        UserStore.addPassword(user, site, pass);
        resp.sendRedirect("dashboard.jsp");
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect("dashboard.jsp");
    }
}
